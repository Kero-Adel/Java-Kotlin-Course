package com.company;

import javax.naming.spi.DirStateFactory;
import javax.xml.transform.Result;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String day;
        System.out.println("Enter your age : ");
        int age = s.nextInt();
        if (age > 21){
            System.out.println("okay");

        }
        else if (age <= 13){
            System.out.println("no");
        }

        else {
            System.out.println("not sure");
        }
        System.out.println("Please Enter the day you want check about");
        day = s.next();
        switch (day){
            case "monday":
                System.out.println("We're opened");
                break;
            case "thursday":
                System.out.println("We're opened");
                break;
            case "friday":
                System.out.println("not today");
                break;
            case "wednesday":
                System.out.println("not today");
                break;
            default:
                System.out.println("For more please contact Us");




        }


    }
}
