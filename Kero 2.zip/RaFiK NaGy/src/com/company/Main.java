package com.company;

import javax.naming.spi.DirStateFactory;
import javax.xml.transform.Result;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int R = firstFun(3,3,3);
        seconFun(R);


    }
    public static int firstFun (int x , int y , int z){

        int multi = x * y * z;

        return multi;
    }


    public static void seconFun (int Result){

        int finalResult = Result + 14;
        System.out.println(finalResult);




    }
}
