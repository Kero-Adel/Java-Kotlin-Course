package com.company;

import javax.naming.spi.DirStateFactory;
import javax.xml.transform.Result;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);


        try {
            System.out.println("Please enter the first number : ");
            int x = s.nextInt();
            System.out.println("Please enter the second number : ");
            int y = s.nextInt();
        }

        catch (Exception Ex) {
            System.out.println("the number is not even");
        }



    }
}
