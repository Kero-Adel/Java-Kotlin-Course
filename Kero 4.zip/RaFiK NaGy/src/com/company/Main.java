package com.company;

import javax.naming.spi.DirStateFactory;
import javax.xml.transform.Result;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        for(int start = 0;start<14;start++){
            System.out.println("I love my parents");

        }
        System.out.println("For Loop");
        int start2 = 0;
        while (start2 <=13){
            System.out.println("I love my parents");
            start2++;
        }
        System.out.println("while Loop");
        int start3 = 1;
        do {
            System.out.println("I love my parents");
            start3++;
        } while (start3 < 15);

        System.out.println("do while Loop");




    }
}
