package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner s = new Scanner (System.in);

        System.out.println("Please enter your name : ");
        String name = s.next();
        System.out.println("Please enter your e-mail : ");
        String email = s.next();
        System.out.println("Your name : "+name+" , Your email : "+email);

    }
}
